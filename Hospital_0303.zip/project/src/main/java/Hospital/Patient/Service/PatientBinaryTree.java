package Hospital.Patient.Service;

import Hospital.Patient.Entity.Patient;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.core.JsonProcessingException;

import java.io.Serializable;




@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL) 
public class PatientBinaryTree implements Serializable {

    private static final long serialVersionUID = 1L; // 직렬화 ID 추가
    @JsonProperty("root") // JSON 변환 시 필드 포함
    private PatientNode root;

    public PatientBinaryTree() {
        this.root = null;
    }
    
    // ✅ 루트 노드 가져오기 (JSON 변환을 위해 필요)
    @JsonIgnore
    public PatientNode getRoot() {
        return root;
    }

    // ✅ BST 삽입 로직
    public boolean insert(Patient newPatient) {
        if (root == null) {
            root = new PatientNode(newPatient);
            return true;
        }
        return insertRecursive(root, newPatient);
    }

    private boolean insertRecursive(PatientNode current, Patient newPatient) {
        if (newPatient.getP_Id() < current.getData().getP_Id()) { 
            if (current.getLeft() == null) {
                current.setLeft(new PatientNode(newPatient));
                return true;
            }
            return insertRecursive(current.getLeft(), newPatient);
        } else if (newPatient.getP_Id() > current.getData().getP_Id()) {
            if (current.getRight() == null) {
                current.setRight(new PatientNode(newPatient));
                return true;
            }
            return insertRecursive(current.getRight(), newPatient);
        }
        return false; // 중복 삽입 방지
    }


}

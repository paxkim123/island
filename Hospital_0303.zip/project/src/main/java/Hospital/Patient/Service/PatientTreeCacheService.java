package Hospital.Patient.Service;

import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.CachePut;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.cache.Cache;
import org.springframework.cache.CacheManager;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import Hospital.Patient.Entity.Patient;

@Service
public class PatientTreeCacheService {
	    private final CacheManager cacheManager;
	    private final ObjectMapper objectMapper;

	    public PatientTreeCacheService(CacheManager cacheManager, ObjectMapper objectMapper) {
	        this.cacheManager = cacheManager;
	        this.objectMapper = objectMapper;
	    }

	    @CachePut(value = "patientTreeCache", key = "'patientTree'")
	    public PatientBinaryTree addPatientToCache(Patient newPatient) {
	        PatientBinaryTree tree = getCachedTree();

	        if (tree == null) {
	            tree = new PatientBinaryTree();
	        }

	        boolean inserted = tree.insert(newPatient);
	        if (!inserted) {
	            System.out.println("[CACHE SKIP] 중복 데이터로 인해 삽입되지 않음: " + newPatient.getP_Id());
	            return tree;
	        }

	        Cache cache = cacheManager.getCache("patientTreeCache");
	        if (cache != null) {
	            cache.put("patientTree", tree);
	            System.out.println("[CACHE UPDATE] 캐시가 업데이트됨: " + tree);
	        }

	        return tree;
	    }

	    @Cacheable(value = "patientTreeCache", key = "'patientTree'")
	    public PatientBinaryTree getCachedTree() {
	        Cache cache = cacheManager.getCache("patientTreeCache");
	        if (cache != null) {
	            PatientBinaryTree tree = cache.get("patientTree", PatientBinaryTree.class);
	            if (tree != null) {
	                return tree;
	            }
	        }
	        return new PatientBinaryTree();
	    }

	    @CacheEvict(value = "patientTreeCache", allEntries = true)
	    public void clearCache() {
	        System.out.println("[CACHE CLEAR] 트리 캐시 초기화 완료");
	    }
}

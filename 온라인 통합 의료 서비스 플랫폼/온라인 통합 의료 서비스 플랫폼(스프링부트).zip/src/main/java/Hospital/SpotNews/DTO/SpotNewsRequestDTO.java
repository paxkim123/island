package Hospital.SpotNews.DTO;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class SpotNewsRequestDTO {
    private String title;
    private String content;
}
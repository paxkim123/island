package Hospital.Patient.Service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import Hospital.Patient.Entity.Patient;

@Component
public class PatientBinaryTree {
    private PatientNode root;

    // 환자 삽입
    public void insert(Patient data) {
        root = insertRec(root, data);
    }

    private PatientNode insertRec(PatientNode root, Patient data) {
        // 루트가 null이면 새로운 노드를 삽입
        if (root == null) {
            return new PatientNode(data);
        }

        // P_Id 기준으로 왼쪽 혹은 오른쪽에 삽입
        if (data.getP_Id() < root.data.getP_Id()) { // P_Id가 현재 노드보다 작으면 왼쪽에 삽입
            root.left = insertRec(root.left, data);
        } else if (data.getP_Id() > root.data.getP_Id()) { // P_Id가 현재 노드보다 크면 오른쪽에 삽입
            root.right = insertRec(root.right, data);
        }

        return root;
    }

    // 환자 검색
    public Patient search(Integer P_Id) {
        return searchRec(root, P_Id);
    }

    private Patient searchRec(PatientNode root, Integer P_Id) {
        if (root == null || root.data.getP_Id().equals(P_Id)) {
            return root != null ? root.data : null;
        }
        if (P_Id < root.data.getP_Id()) {
            return searchRec(root.left, P_Id);
        }
        return searchRec(root.right, P_Id);
    }

    // 피라미드 형태로 출력하는 메서드
    public void printPyramid() {
        int height = getHeight(root); // 트리 높이 구하기
        List<List<Integer>> levels = new ArrayList<>();
        
        // 레벨별로 노드 데이터를 수집
        collectLevels(root, 0, levels);

        // 출력
        for (int i = 0; i < levels.size(); i++) {
            List<Integer> level = levels.get(i);
            
            // 피라미드 정렬을 위한 공백 출력
            int spaces = (int) Math.pow(2, height - i) - 1;
            printSpaces(spaces);
            
            // 노드 데이터 출력
            for (Integer value : level) {
                System.out.print(value);
                printSpaces(spaces * 2); // 다음 값과 간격 유지
            }
            System.out.println(); // 줄 바꿈
        }
    }

    // 트리 높이 구하기
    private int getHeight(PatientNode node) {
        if (node == null) return 0;
        return 1 + Math.max(getHeight(node.left), getHeight(node.right));
    }

    // 레벨별로 노드 수집
    private void collectLevels(PatientNode node, int level, List<List<Integer>> levels) {
        if (node == null) return;

        if (levels.size() <= level) {
            levels.add(new ArrayList<>());
        }

        levels.get(level).add(node.data.getP_Id());

        collectLevels(node.left, level + 1, levels);
        collectLevels(node.right, level + 1, levels);
    }

    // 공백 출력
    private void printSpaces(int count) {
        for (int i = 0; i < count; i++) {
            System.out.print(" ");
        }
    }
 // 트리 구조를 JSON 형식으로 반환하는 메서드
    public String getTreeStructureJson() {
        if (root == null) {
            return "{}"; // 빈 트리일 경우 빈 JSON 반환
        }
        ObjectMapper objectMapper = new ObjectMapper();
        try {
            return objectMapper.writeValueAsString(root);
        } catch (JsonProcessingException e) {
            e.printStackTrace();
            return "{}";
        }
    }

    private String getTreeStructureJsonRec(PatientNode node) {
        if (node == null) {
            return "{}";
        }

        String leftJson = getTreeStructureJsonRec(node.left);
        String rightJson = getTreeStructureJsonRec(node.right);

        return String.format("{\"P_Id\": \"%d\", \"left\": %s, \"right\": %s}",
                             node.data.getP_Id(),
                             leftJson,
                             rightJson);
    }
}
package Hospital.Login.DTO;


import java.security.SecureRandom;


import lombok.Getter;
import lombok.NonNull;
import lombok.Setter;

@Getter
@Setter
public class UserInfoCreateDTO {
	@NonNull
	private String UserId;
	@NonNull
	private String UserPw;
	@NonNull
	private String UserName;
	@NonNull
	private String UserRegNum;
	@NonNull
	private String UserGender;
	@NonNull
	private String UserPhone;
	@NonNull
	private String UserAddress1;
	@NonNull
	private String UserAddress2;
	@NonNull
	private String Salt;
	
	private UserInfoCreateDTO() {
	     this.Salt = generateSalt();
	     System.out.println(Salt);
	}

	 private String generateSalt() {
	     SecureRandom random = new SecureRandom();
	     byte[] salt = new byte[16];
	     random.nextBytes(salt);
	     return Byte_to_String(salt);
	 }
	 
	 private String Byte_to_String(byte[] temp) {
		StringBuilder sb = new StringBuilder();
		for(byte a: temp) {
			sb.append(String.format("%02x", a));
		}
		return sb.toString();
	}
}

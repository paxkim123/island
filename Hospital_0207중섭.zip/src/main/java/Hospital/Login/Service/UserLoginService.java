package Hospital.Login.Service;


import java.security.MessageDigest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import Hospital.Login.DTO.UserInfoCreateDTO;
import Hospital.Login.Entity.UserInfo;
import Hospital.Login.Entity.UserInfoRepository;

@Service
public class UserLoginService {
	
	@Autowired
	private UserInfoRepository uir;
	
	//로그인 실행 로직
	public String UserLogin(String UserId, String UserPw) throws Exception{
		UserInfo userinfo = this.uir.findById(UserId).orElse(null);
		if(userinfo==null) {
			return "IdError";
		}
		else if(!userinfo.getUserPw().equals(Hashing(UserPw.getBytes(), userinfo.getSalt()))) {
			return "PwError";
		}
		return "Success";
	}
	
	//회원 가입 로직 (제출시 DB에 등록)
	public void UserInfoRegister(UserInfoCreateDTO uicDTO) throws Exception {
		UserInfo userinfo = UserInfo.builder()
					.UserId(uicDTO.getUserId())
					.Salt(uicDTO.getSalt())
					.UserPw(Hashing(uicDTO.getUserPw().getBytes(), uicDTO.getSalt()))
					.UserName(uicDTO.getUserName())
					.UserRegNum(uicDTO.getUserRegNum())
					.UserGender(uicDTO.getUserGender())
					.UserPhone(uicDTO.getUserPhone())
					.UserAddress1(uicDTO.getUserAddress1())
					.UserAddress2(uicDTO.getUserAddress2())
					.build();
		this.uir.save(userinfo); // 회원 정보 저장
	}
	
	public String Byte_to_String(byte[] temp) {
		StringBuilder sb = new StringBuilder();
		for(byte a: temp) {
			sb.append(String.format("%02x", a));
		}
		return sb.toString();
	}
	
	public String Hashing(byte[] password, String salt) throws Exception{
		MessageDigest md = MessageDigest.getInstance("SHA-256"); 
		for(int i = 0; i < 10000; i++) {
			String temp = Byte_to_String(password)+salt;
			md.update(temp.getBytes());
			password = md.digest();
		}
		return Byte_to_String(password);
	}
	
	//회원 가입 아이디 중복 확인 버튼 로직
	public boolean UserIdCheck(String UserId) {
		return this.uir.existsById(UserId);
	}
	
	public void UserInfoModify(UserInfoCreateDTO uicDTO) {
		UserInfo userinfo = UserInfo.builder()
				.UserPw(uicDTO.getUserPw())
				.UserName(uicDTO.getUserName())
				.UserRegNum(uicDTO.getUserRegNum())
				.UserGender(uicDTO.getUserGender())
				.UserPhone(uicDTO.getUserPhone())
				.UserAddress1(uicDTO.getUserAddress1())
				.UserAddress2(uicDTO.getUserAddress2())
				.build();
		this.uir.save(userinfo);
	}
	
}

package Hospital.Board.Controller;

import java.util.List;


import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

import Hospital.Board.DTO.BoardDTO;
import Hospital.Board.Service.BoardService;
import jakarta.servlet.http.HttpSession;


@Controller
public class BoardController {
	
	
    private BoardService bs;

	public BoardController(BoardService bs) {
        this.bs = bs;
    }
   
    @GetMapping("/BoardPage/List")
    public String BoardList(HttpSession session, Model model) {
        List<BoardDTO> boardDTOList = bs.GetBoardList();
        model.addAttribute("postList", boardDTOList);
        String UserId = (String) session.getAttribute("UserId");
        if(UserId != null) {
        	model.addAttribute("UserId", UserId);
        }
        return "/BoardPage/List.html";
    }
    
    @GetMapping("/BoardPage/Write")
    public String BoardCreate() {
        return "/BoardPage/Write.html";
    }

    @PostMapping("/BoardPage/Write")
    public String BoardWrite(BoardDTO boardDto) {
        bs.SavePost(boardDto);
        return "redirect:/BoardPage/List";
    }
}
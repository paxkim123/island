package Hospital;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

@SpringBootApplication
//@EnableJpaRepositories(basePackages = "Hospital.src.main.java.Hospital.VM.Service")
@EnableJpaRepositories
public class HospitalApplication {

	public static void main(String[] args) {
		SpringApplication.run(HospitalApplication.class, args);
	}

}
//병원예약 - 특정 병원 - (DB에 예약 환자 칼럼 = 로그인 회원 병원예약시 해당 병원 DB의 예약현황 칼럼에 숫자 1 추가)
//draw.io

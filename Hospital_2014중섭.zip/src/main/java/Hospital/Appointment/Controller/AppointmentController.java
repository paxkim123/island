package Hospital.Appointment.Controller;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.NoSuchElementException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import Hospital.Appointment.DTO.AppointmentDTO;
import Hospital.Appointment.Service.AppointmentService;
import Hospital.Patient.Entity.D_Hospital;
import Hospital.Patient.Entity.D_HospitalRepository;
import jakarta.servlet.http.HttpSession;


@Controller
public class AppointmentController {


	@Autowired
    private D_HospitalRepository d_hr;
    
	@Autowired
    private AppointmentService appointmentService; // AppointmentService 추가
    
    
    
    // 병원 목록을 검색하는 GET 요청 처리
    @GetMapping("/AppointmentPage/Input")
    public ModelAndView searchHospitals(
            @RequestParam(value = "H_Name", required = false) String H_Name,
            @RequestParam(value = "H_Region", required = false) String H_Region, HttpSession session) {

        System.out.println("======== 컨트롤러 진입 ========");
        System.out.println("H_Name: " + H_Name);
        System.out.println("H_Region: " + H_Region);
        String id = (String) session.getAttribute("UserId");
        System.out.println(id);

        // null 체크
        if (H_Name == null) H_Name = "";
        if (H_Region == null) H_Region = "";

        List<D_Hospital> allHospitalList = this.d_hr.findAll();
        System.out.println("DB에서 불러온 전체 병원 개수: " + allHospitalList.size());

        List<D_Hospital> filteredList = new ArrayList<>();
        for (D_Hospital hospital : allHospitalList) {
            if (hospital.getH_Region().contains(H_Region) && hospital.getH_Name().contains(H_Name)) {
                filteredList.add(hospital);
            }
        }

        System.out.println("검색된 병원 개수: " + filteredList.size());

        ModelAndView mav = new ModelAndView();
        mav.addObject("D_HospitalList", filteredList);
        mav.setViewName("AppointmentPage/Input");
        return mav;
    }
    
    @PostMapping("/AppointmentPage/Reserve")
    public String reserveAppointment(@RequestParam("selectedHospitals") Integer hospitalId,  // 선택된 병원 ID
                                     @RequestParam(value = "patientName") String patientName,                   // 환자 성명
                                     @RequestParam(value = "appointmentTime") LocalDateTime appointmentTime,
                                     HttpSession session// 예약 시간
                                   ) {                        // 사용자 ID
    	String userId = (String) session.getAttribute("UserId");
        System.out.println("hospitalId: " + hospitalId);
        System.out.println("patientName: " + patientName);
        System.out.println("appointmentTime: " + appointmentTime);
        System.out.println("userId: " + userId);
        // 예약 DTO로 데이터 전달
        AppointmentDTO appointmentDTO = new AppointmentDTO();
        appointmentDTO.setHospitalId(hospitalId);  // 병원 ID
        appointmentDTO.setPatientName(patientName); // 환자 성명
        appointmentDTO.setAppointmentTime(appointmentTime); // 예약 시간
        appointmentDTO.setUserId(userId); // 사용자 ID

        // 예약 처리 서비스 호출
        appointmentService.createAppointment(appointmentDTO);

        return "redirect:/AppointmentPage/Confirm"; // 예약 확인 페이지로 리디렉션
    }
   
	
}
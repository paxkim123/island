package Hospital.Patient.Controller;

import Hospital.Patient.Service.PatientTreeCacheService;
import Hospital.Patient.Service.PatientBinaryTree;
import Hospital.Patient.Entity.Patient;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Optional;

@RestController
@RequestMapping("/api/patient/tree")
public class PatientTreeController {

    @Autowired
    private PatientTreeCacheService treeCacheService;

    /**
     * 🔹 캐시에서 트리 데이터를 가져오기
     */
    @GetMapping
    public ResponseEntity<?> getPatientTree() {
        try {
            PatientBinaryTree tree = treeCacheService.getPatientTree();

            System.out.println("[DEBUG] 캐시에서 가져온 트리: " + tree);
            if (tree == null || tree.getRoot() == null) {
                return ResponseEntity.status(HttpStatus.NO_CONTENT).body("트리 데이터 없음");
            }
            return ResponseEntity.ok(tree.getTreeStructureJson());
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("트리 데이터를 가져오는 중 오류 발생: " + e.getMessage());
        }
    }

    /**
     * 🔹 새 환자 추가 및 트리 업데이트
     */
    @PostMapping("/insert")
    public ResponseEntity<String> insertPatient(@RequestBody Patient patient) {
        try {
            System.out.println("[DEBUG] 새로운 환자 추가 요청: " + patient.getP_Name());
            treeCacheService.addPatientToTree(patient);
            return ResponseEntity.ok("환자가 트리에 추가되었습니다: " + patient.getP_Name());
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("트리에 환자를 추가하는 중 오류 발생: " + e.getMessage());
        }
    }

    /**
     * 🔹 트리 디버깅 (루트 데이터 확인)
     */
    @GetMapping("/debug")
    public ResponseEntity<String> debugPatientTree() {
        PatientBinaryTree tree = treeCacheService.getPatientTree();

        if (tree == null || tree.getRoot() == null) {
            return ResponseEntity.ok("트리에 데이터가 없습니다. (캐시가 비어 있음)");
        }

        return ResponseEntity.ok("트리 루트 데이터: " + tree.getRoot().getData().getP_Name());
    }

    /**
     * 🔹 캐시 초기화 API
     */
    @GetMapping("/clear")
    public ResponseEntity<String> clearCache() {
        treeCacheService.clearCache();
        return ResponseEntity.ok("트리 캐시 초기화 완료");
    }
}

package Hospital.Patient.Entity;

import java.time.LocalDateTime;
import java.util.Random;

import org.hibernate.annotations.CreationTimestamp;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.datatype.jsr310.ser.LocalDateTimeSerializer;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.PrePersist;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Patient {

    @Id
    private Integer P_Id;  // @GeneratedValue 제거
    
    @Column
    private String P_UserId;
    
    @Column
    private String P_Name;
    
    @Column   
    private String P_Gender;
    
    @Column
    private Integer P_RegNum;
    
    @Column
    private String P_Phone;
    
    @Column
    private String P_Address1;
    
    @Column
    private String P_Address2;
    
    @Column
    private Integer P_TakingPill;
    
    @Column
    private Integer P_Nose;
    
    @Column
    private Integer P_Cough;
    
    @Column
    private Integer P_Pain;
    
    @Column
    private Integer P_Diarrhea;
    
    @Column
    private String P_HighRiskGroup;
    
    @Column
    private Integer P_VAS;
    
    @Column
    private Integer P_Agreement;
    
    @CreationTimestamp
    @JsonIgnore
    //자바에서 localdatetime은 json 파일 형식으로 지원되지 않아서 강제 형변환을 하거나 다른 클래스 파일을 통해 
    //변환해주어야 하나 굳이 담지 않아도 될 정보인 것 같아 json 변환 시 localdatetime을 무시하기 위한 어노테이션 첨가
    private LocalDateTime P_InsertDateTime;
    
    // P_Id 생성자 추가 (난수 8자리 생성)
    @PrePersist
    public void generateRandomPId() {
        if (this.P_Id == null) {
            this.P_Id = generateRandomId();
        }
    }
    
    // 8자리 난수 생성
    private Integer generateRandomId() {
        Random rand = new Random();
        // 8자리 난수 생성 (10000000 ~ 99999999)
        return rand.nextInt(90000000) + 10000000;
    }

    // Getter and Setter methods
    public Integer getP_Id() {
        return P_Id;
    }

    public void setP_Id(Integer P_Id) {
        this.P_Id = P_Id;
    }
}
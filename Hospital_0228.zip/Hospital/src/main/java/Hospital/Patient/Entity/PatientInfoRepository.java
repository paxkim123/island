package Hospital.Patient.Entity;

import org.springframework.data.jpa.repository.JpaRepository;


public interface PatientInfoRepository extends JpaRepository<Patient, Integer> {

}

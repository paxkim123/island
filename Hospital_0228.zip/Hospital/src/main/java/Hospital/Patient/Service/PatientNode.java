package Hospital.Patient.Service;
import com.fasterxml.jackson.annotation.*;


import Hospital.Patient.Entity.Patient;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@JsonIgnoreProperties(ignoreUnknown = true)  // Jackson이 알 수 없는 속성을 무시
@JsonInclude(JsonInclude.Include.NON_NULL)  // NULL 값은 JSON 변환 시 제외
public class PatientNode {

    Patient data;  // JSON 변환 시 전체 Patient 객체를 포함

    @JsonIgnore  // 순환 참조 방지
    PatientNode left;

    @JsonIgnore  // 순환 참조 방지
    PatientNode right;

    // ✅ 개별 JSON 속성 추가 (선택적 사용)
    @JsonProperty("P_Id")
    public Integer getPId() {
        return data != null ? data.getP_Id() : null;
    }

    @JsonProperty("P_Name")
    public String getPName() {
        return data != null ? data.getP_Name() : null;
    }

    @JsonProperty("P_Gender")
    public String getPGender() {
        return data != null ? data.getP_Gender() : null;
    }

    @JsonProperty("P_Phone")
    public String getPPhone() {
        return data != null ? data.getP_Phone() : null;
    }

    @JsonProperty("P_Address1")
    public String getPAddress1() {
        return data != null ? data.getP_Address1() : null;
    }

    @JsonProperty("P_Address2")
    public String getPAddress2() {
        return data != null ? data.getP_Address2() : null;
    }

    public PatientNode(Patient data) {
        this.data = data;
        this.left = null;
        this.right = null;
    }
}

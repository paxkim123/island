package Hospital.Patient.Service;

import Hospital.Patient.Entity.Patient;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.core.JsonProcessingException;
import org.springframework.stereotype.Component;

@Component
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class PatientBinaryTree {
    private PatientNode root;

    public void insert(Patient patient) {
        System.out.println("[DEBUG] insert() 호출됨: " + patient.getP_Name());
        root = insertRec(root, patient);
        System.out.println("[DEBUG] 트리에 추가됨: " + root.data.getP_Name());
    }

    private PatientNode insertRec(PatientNode root, Patient data) {
        if (root == null) {
            return new PatientNode(data);
        }
        if (data.getP_Id() < root.data.getP_Id()) {
            root.left = insertRec(root.left, data);
        } else if (data.getP_Id() > root.data.getP_Id()) {
            root.right = insertRec(root.right, data);
        }
        return root;
    }

    public String getTreeStructureJson() {
        if (root == null) {
            return "{}";
        }
        ObjectMapper objectMapper = new ObjectMapper();
        try {
            return objectMapper.writeValueAsString(root);
        } catch (JsonProcessingException e) {
            e.printStackTrace();
            return "{}";
        }
    }

    public PatientNode getRoot() {
        return root;
    }
    /**
     * 🔹 환자 검색 (P_Id 기준)
     */
    public Patient search(Integer P_Id) {
        return searchRec(root, P_Id);
    }

    private Patient searchRec(PatientNode root, Integer P_Id) {
        if (root == null || root.data.getP_Id().equals(P_Id)) {
            return root != null ? root.data : null;
        }
        if (P_Id < root.data.getP_Id()) {
            return searchRec(root.left, P_Id);
        }
        return searchRec(root.right, P_Id);
    }
}

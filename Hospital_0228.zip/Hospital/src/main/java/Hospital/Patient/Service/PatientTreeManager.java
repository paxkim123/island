package Hospital.Patient.Service;

import org.springframework.stereotype.Component;

@Component
public class PatientTreeManager {
    private final PatientBinaryTree patientTree = new PatientBinaryTree();

    public PatientBinaryTree getTree() {
        return patientTree;
    }
}

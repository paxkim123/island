package Hospital.Patient.Service;

import Hospital.Patient.Entity.Patient;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.cache.annotation.CachePut;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.stereotype.Service;

@Service
public class PatientTreeCacheService {

    private PatientBinaryTree patientTree = new PatientBinaryTree(); // 초기 트리 생성

    /**
     * 🔹 캐시에서 트리 가져오기 (기존 트리 유지)
     */
    @Cacheable(value = "patientTreeCache")
    public PatientBinaryTree getPatientTree() {
        System.out.println("[CACHE] 캐시에서 트리 가져오기");
        return patientTree;
    }

    /**
     * 🔹 트리에 새로운 환자 추가 (기존 트리 유지)
     */
    @CachePut(value = "patientTreeCache")
    public PatientBinaryTree addPatientToTree(Patient patient) {
        if (patientTree == null) {
            patientTree = new PatientBinaryTree(); // 기존 트리가 없으면 새로 생성
        }
     // 🔹 중복 추가 방지: 이미 존재하는 환자인지 확인
        if (patientTree.search(patient.getP_Id()) == null) {
            System.out.println("[CACHE UPDATE] 트리에 새로운 환자 추가됨: " + patient.getP_Name());
            patientTree.insert(patient);  // 새 환자 삽입
        } else {
            System.out.println("[CACHE] 이미 존재하는 환자이므로 추가하지 않음: " + patient.getP_Name());
        }
        patientTree.insert(patient); // 새 환자 삽입
        return patientTree;
    }

    /**
     * 🔹 캐시 초기화 (트리 삭제)
     */
    @CacheEvict(value = "patientTreeCache", allEntries = true)
    public void clearCache() {
        System.out.println("[CACHE CLEAR] 트리 캐시 초기화 완료");
        patientTree = new PatientBinaryTree(); // 새로운 트리로 초기화
    }
}
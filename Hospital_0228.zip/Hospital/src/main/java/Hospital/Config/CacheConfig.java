package Hospital.Config;

import org.springframework.cache.annotation.EnableCaching;
import org.springframework.context.annotation.Configuration;

@Configuration
@EnableCaching  // 캐싱 활성화
public class CacheConfig {
}

package Hospital.AllertController;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.*;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestTemplate;

import Hospital.D_Hospital.Service.D_HospitalService;
import Hospital.Patient.Entity.Patient;
import Hospital.Patient.Entity.PatientRepository;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

@Controller
public class AlertController {

    private final RestTemplate restTemplate = new RestTemplate();

    @Autowired
    private PatientRepository patientRepository;
    
    @Autowired
    private D_HospitalService d_hs;

    @PostMapping("/api/check-covid-proximity")
    public ResponseEntity<String> checkAndAlert(@RequestBody Map<String, Object> location) {
        BigDecimal latitude = new BigDecimal(location.get("latitude").toString());
        BigDecimal longitude = new BigDecimal(location.get("longitude").toString());

        // 감염자만 필터링된 환자 리스트 가져오기
        List<Patient> infectedPatients = patientRepository.findByP_Covid19();

        boolean nearInfected = infectedPatients.stream().anyMatch(patient -> {
            BigDecimal distance = d_hs.distanceFromEachOther(
                latitude, longitude,
                patient.getP_Latitude(), patient.getP_Longitude()
            );
            return distance.compareTo(new BigDecimal("0.0009")) <= 0; //100M보다 훨씬 큰 반경으로 미리 기존 데이터 테스트
        });

        if (nearInfected) {
            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.TEXT_PLAIN);

            HttpEntity<String> request = new HttpEntity<>("ALERT: 감염자 접근", headers);

            try {
                ResponseEntity<String> response = restTemplate.postForEntity(
                        "http://172.30.1.16:8081", request, String.class
                );
                return ResponseEntity.ok("⚠️ 경고 전송 성공: " + response.getBody());
            } catch (Exception e) {
                return ResponseEntity.status(500).body("❌ 경고 전송 실패: " + e.getMessage());
            }
        }

        return ResponseEntity.ok("정상 반경입니다.");
    }

}


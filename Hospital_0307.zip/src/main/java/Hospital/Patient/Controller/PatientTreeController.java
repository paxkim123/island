package Hospital.Patient.Controller;

import Hospital.Patient.Service.PatientBinaryTree;
import Hospital.Patient.Service.PatientTreeCacheService;
import Hospital.Patient.Entity.Patient;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.fasterxml.jackson.databind.ObjectMapper;


@RestController
@RequestMapping("/api/patient")
public class PatientTreeController {
	private final PatientTreeCacheService cacheService;
    private final ObjectMapper objectMapper;

    public PatientTreeController(PatientTreeCacheService cacheService, ObjectMapper objectMapper) {
        this.cacheService = cacheService;
        this.objectMapper = objectMapper;
    }

    @PostMapping
    public ResponseEntity<String> addPatient(@RequestBody Patient patient) {
        cacheService.addPatientToCache(patient);
        return ResponseEntity.ok("환자 정보가 추가되었습니다.");
    }

    @GetMapping("/tree")
    public ResponseEntity<String> getPatientTree() {
        PatientBinaryTree tree = cacheService.getCachedTree();
        if (tree == null || tree.getRoot() == null) {
            return ResponseEntity.ok("{}"); // 트리가 없을 경우 빈 JSON 반환
        }

        try {
            String jsonTree = objectMapper.writeValueAsString(tree.getRoot()); // 루트 노드부터 변환
            System.out.println("[API RESPONSE] 변환된 트리: " + jsonTree);
            return ResponseEntity.ok(jsonTree);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                                 .body("{\"error\":\"JSON 변환 오류\"}");
        }
    }

    @DeleteMapping("/cache")
    public ResponseEntity<String> clearCache() {
        cacheService.clearCache();
        return ResponseEntity.ok("캐시가 초기화되었습니다.");
    }
}

package Hospital.Patient.Service;
import java.io.Serializable;

import com.fasterxml.jackson.annotation.*;


import Hospital.Patient.Entity.Patient;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@JsonIgnoreProperties(ignoreUnknown = true)  // Jackson이 알 수 없는 속성을 무시
@JsonInclude(JsonInclude.Include.NON_NULL)  // NULL 값은 JSON 변환 시 제외
public class PatientNode implements Serializable {
    private static final long serialVersionUID = 1L; // 직렬화 버전 ID 추가
	@JsonIgnore
    Patient data;  // JSON 변환 시 전체 Patient 객체를 포함
	//json이 localdatetime을 변환시키지 못하면서 설정했던 다른 요건들을 정리함
	//json으로 직접적인 변환을 하진 않으나 Patient data 중 json으로 변환하고자 하는 데이터만
	//아래의 코드를 통해 추출하여 저장 및 전송 

	 @JsonProperty("left") // JSON 변환 시 필드 포함
	 public PatientNode left;

	 @JsonProperty("right") // JSON 변환 시 필드 포함
	 public PatientNode right;

    // ✅ 개별 JSON 속성 추가 (선택적 사용)
    @JsonProperty("P_Id")
    public Integer getPId() {
        return data != null ? data.getP_Id() : null;
    }

    @JsonProperty("P_Name")
    public String getPName() {
        return data != null ? data.getP_Name() : null;
    }

    @JsonProperty("P_Gender")
    public String getPGender() {
        return data != null ? data.getP_Gender() : null;
    }

    @JsonProperty("P_Phone")
    public String getPPhone() {
        return data != null ? data.getP_Phone() : null;
    }

    @JsonProperty("P_Address1")
    public String getPAddress1() {
        return data != null ? data.getP_Address1() : null;
    }

    @JsonProperty("P_Address2")
    public String getPAddress2() {
        return data != null ? data.getP_Address2() : null;
    }

    public PatientNode(Patient data) {
        this.data = data;
        this.left = null;
        this.right = null;
    }
 
}
